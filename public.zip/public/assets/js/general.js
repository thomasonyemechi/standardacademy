function term_text(term) {
    val = '';
    if (term == 1) {
        val = 'First Term'
    } else if (term == 2) {
        val = 'Second Term'
    } else if (term == 3) {
        val = 'Third Term';
    }

    return val;
}
