@extends('layout.student')
@section('page_title')
    Dashboard
@endsection
@section('page_content')
    <div class="row">
        <h5>hry</h5>
    </div>
@endsection
